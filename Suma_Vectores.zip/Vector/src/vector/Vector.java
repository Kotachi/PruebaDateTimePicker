/*
 * Crear un programa que pida insertar 5 valores a un arreglo de enteros y que entregue:
Promedio
Mayor
Menor
Suma
Producto

 */
package vector;

import java.util.*;
public class Vector {

   
    public static void main(String[] args) {
               int [] vector; int mayor=0, menor=0;
        double prom = 0;
        long producto = 1;
        vector = new int[4];
        Scanner leer = new Scanner(System.in);
       
        for (int i = 0; i <vector.length; i++)
        {
            System.out.println("Ingrese numero "+ (i+1));
            vector [i] = leer.nextInt();
              prom +=vector[i];
              producto *=vector[i];
        }
        menor = vector[0];
          for (int x=1;x<vector.length;x++)
          {
              if (vector[x]< menor)
                  menor = vector[x];
          }
         mayor= vector[0];
          for (int x=0;x<vector.length;x++)
          {
              if (vector[x]>mayor)
                  mayor = vector[x];
          }
        System.out.println("El promedio es: " + prom/vector.length);
        System.out.println("La suma del vector es: " + prom);
        System.out.println("El producto del vector es: " + producto); 
        System.out.println("El numero menor es: " + menor);
        System.out.println("El numero mayor es: " + mayor);
    }
}
    
