package ip;
import java.util.Scanner;
public class BBDD {
    Scanner teclado = new Scanner(System.in);
    Alumno[] BDAl= new Alumno[100];
    Docente[] BDDo= new Docente[100];
    Administrativo[] BDAd= new Administrativo[100];
    int conAl = 0;
    int conDo = 0;
    int conAd = 0;
    public void GuardaAlumno(){
        BDAl[conAl] = new Alumno();
        System.out.print("Ingrese Nombre: ");
        BDAl[conAl].setNombre(teclado.nextLine());
        System.out.print("Ingrese Sexo: ");
        BDAl[conAl].setSexo(teclado.nextLine());
        System.out.print("Ingrese Edad: ");
        BDAl[conAl].setEdad(teclado.nextInt());
        System.out.print("Ingrese Matricula: ");
        BDAl[conAl].setMatricula(teclado.nextInt());
        teclado.nextLine();
        conAl++;
    }
    
    public void GuardaDocente(){
        BDDo[conDo] = new Docente();
        System.out.print("Ingrese Nombre: ");
        BDDo[conDo].setNombre(teclado.nextLine());
        System.out.print("Ingrese Sexo: ");
        BDDo[conDo].setSexo(teclado.nextLine());
        System.out.print("Ingrese Edad: ");
        BDDo[conDo].setEdad(teclado.nextInt());
        System.out.print("Ingrese Profesion: ");
        BDDo[conDo].setProfesion(teclado.nextLine());
        teclado.nextLine();
        conDo++;
    }
    
    public void GuardaAdministrativo(){
        BDAd[conAd] = new Administrativo();
        System.out.print("Ingrese Nombre: ");
        BDAd[conAd].setNombre(teclado.nextLine());
        System.out.print("Ingrese Sexo: ");
        BDAd[conAd].setSexo(teclado.nextLine());
        System.out.print("Ingrese Cargo: ");
        BDAd[conAd].setCargo(teclado.nextLine());
        System.out.print("Ingrese Edad: ");
        BDAd[conAd].setEdad(teclado.nextInt());
        teclado.nextLine();
        conAd++;
    }
    
    public void Listar(){
        if(conAl != 0){
            System.out.println("Alumnos:");
            for(int i=0;i<conAl;i++ ){
                System.out.println("\tNombre:"+BDAl[i].getNombre());
                System.out.println("\t\tSexo:"+BDAl[i].getSexo());
                System.out.println("\t\tEdad:"+BDAl[i].getEdad());
                System.out.println("\t\tMatricula:"+BDAl[i].getMatricula());
            }
        }
        if(conDo != 0){
            System.out.println("Docentes:");
            for(int i=0;i<conDo;i++ ){
                System.out.println("\tNombre:"+BDDo[i].getNombre());
                System.out.println("\t\tSexo:"+BDDo[i].getSexo());
                System.out.println("\t\tEdad:"+BDDo[i].getEdad());
                System.out.println("\t\tProfesion:"+BDDo[i].getProfesion());
            }
        }
        if(conAd != 0){
            System.out.println("Administrativos:");
            for(int i=0;i<conAd;i++ ){
                System.out.println("\tNombre:"+BDAd[i].getNombre());
                System.out.println("\t\tSexo:"+BDAd[i].getSexo());
                System.out.println("\t\tEdad:"+BDAd[i].getEdad());
                System.out.println("\t\tCargo:"+BDAd[i].getCargo());
            }
        }
    }
    
}
