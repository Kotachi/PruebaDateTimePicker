package ip;

public class Persona {
    String Nombre;
    int Edad;
    String Sexo;
    public Persona(){
        this.Nombre=this.Sexo=null;
        this.Edad=0;
    }
    public void setNombre(String n){
        this.Nombre = n;
    }
    public void setEdad(int e){
        this.Edad = e;
    }
    public void setSexo(String s){
        this.Sexo = s;
    }
    public String getNombre(){
        return(this.Nombre);
    }
    public int getEdad(){
        return(this.Edad);
    }
    public String getSexo(){
        return(this.Sexo);
    }
}
