package ip;
import java.util.Scanner;
public class IP {
        public static void main(String[] args) {
        int opcion = 0;
        Scanner tecla = new Scanner(System.in);
        BBDD ip = new BBDD();
        do{
            System.out.println("Menu:");
            System.out.println("\t 1: Ingresar Alumno");
            System.out.println("\t 2: Ingresar Profesor");
            System.out.println("\t 3: Ingresar Administrativo");
            System.out.println("\t 4: Listar");
            System.out.println("\t 0: Salir");
            System.out.print("Ingrese Opcion: ");
            opcion = tecla.nextInt();
            
            switch(opcion){
                case 1:
                    ip.GuardaAlumno();
                    break;
                case 2:
                    ip.GuardaDocente();
                    break;
                case 3:
                    ip.GuardaAdministrativo();
                    break;
                case 4:
                    ip.Listar();
                    break;
                case 0:
                    System.out.println("Saliendo...");
                    break;
                default:
                    System.out.println("Opcion no valida");
                    break;
            }
            
        }while(opcion!=0);
    }
}