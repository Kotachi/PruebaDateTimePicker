package ip;

public class Docente extends Persona{
    String Profesion;
    
    public void setProfesion(String c){
        this.Profesion = c;
    }
    public String getProfesion(){
        return(this.Profesion);
    }
}
