/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


var semana = ["lunes","martes","miercoles","jueves","viernes","sabado","domingo"];
var CantDiasSemana= semana.lenght;
var vocales = ["a","e","i","o","u"];
var cantVocales = vocales.lenght;
alert (CantDiasSemana,cantVocales);